from django.apps import AppConfig


class CalculatorappConfig(AppConfig):
    name = 'calculatorapp'
